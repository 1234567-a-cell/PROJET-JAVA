/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import projet.entity.Classe;
import projet.entity.commentaire;
import projet.services.ServiceClass;
import projet.services.ServiceCommentaire;

/**
 * FXML Controller class
 *
 * @author Espace Info
 */
public class Modifier_commentaireController implements Initializable {

    @FXML
    private JFXButton id_affich_comm;
    @FXML
    private TextField id_email;
    @FXML
    private JFXDatePicker id_combo_date;
    @FXML
    private TextField id_contenu;
    @FXML
    private JFXButton id_modif_com;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    


    @FXML
    private void affich(MouseEvent event) throws IOException {
           Stage stage=(Stage)this.id_affich_comm.getScene().getWindow();
       Parent root=FXMLLoader.load(getClass().getResource("afficher_commentaire.fxml"));
       Projet.Curseur(root);
       Scene scene=new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    private void back(MouseEvent event) {
    }

    @FXML
    private void modify(MouseEvent event) throws SQLException {
         ServiceCommentaire cl=new ServiceCommentaire();
        commentaire t=new commentaire(Projet.id_sav,this.id_combo_date.getValue(),this.id_email.getText(),this.id_contenu.getText());
        System.out.println(t);
     cl.update(t);
    }
    
}
